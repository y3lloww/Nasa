package com.example.nasaphotoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    private static final String API_KEY = "qoISYys7LGL8tOjXGzoeAFgt36Q5KKx2TYSGW3vU";  // Zastąp swoim kluczem API
    private ImageView photoImageView;
    private TextView titleTextView;
    private TextView descriptionTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        photoImageView = findViewById(R.id.photoImageView);
        titleTextView = findViewById(R.id.titleTextView);
        descriptionTextView = findViewById(R.id.descriptionTextView);

        Button loadPhotoButton = findViewById(R.id.loadPhotoButton);
        loadPhotoButton.setOnClickListener(v -> loadPhotoOfTheDay());
    }

    private void loadPhotoOfTheDay() {
        NasaApiService apiService = RetrofitClient.getInstance();
        Call<NasaPhoto> call = apiService.getPhotoOfTheDay(API_KEY);

        call.enqueue(new Callback<NasaPhoto>() {
            @Override
            public void onResponse(Call<NasaPhoto> call, Response<NasaPhoto> response) {
                if (response.isSuccessful()) {
                    NasaPhoto photo = response.body();
                    titleTextView.setText(photo.getTitle());
                    descriptionTextView.setText(photo.getExplanation());
                    Glide.with(MainActivity.this)
                            .load(photo.getUrl())
                            .into(photoImageView);
                }
            }

            @Override
            public void onFailure(Call<NasaPhoto> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
