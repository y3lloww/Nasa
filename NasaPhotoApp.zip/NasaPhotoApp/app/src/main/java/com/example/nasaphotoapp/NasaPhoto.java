package com.example.nasaphotoapp;

public class NasaPhoto {
    private String title;
    private String explanation;
    private String url;
    private String date;

    // Getters
    public String getTitle() {
        return title;
    }

    public String getExplanation() {
        return explanation;
    }

    public String getUrl() {
        return url;
    }

    public String getDate() {
        return date;
    }
}
